SamacSys EAGLE ULP


1. Select File->Open->Script... from the EAGLE Control Panel, and open "eagle.scr" from the "scr" folder.
Add the following line (including the spaces) within the "MENU" sections of both "BRD:" and "SCH:":
     '[bin/samacsys.png] SamacSys : Run samacsys.ulp;'\

2. Copy samacsys.ulp to the "ulp" folder under the EAGLE installation directory.

3. Copy samacsys.png to the "bin" folder under the EAGLE installation directory.